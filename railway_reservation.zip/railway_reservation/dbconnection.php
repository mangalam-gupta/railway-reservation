<?php
$host = "localhost";
$username = "root";
$password = "";
$db_name="railreservation";
$conn = mysqli_connect('localhost','root','','railreservation') or die('could not connect to mysqli'.mysqli_error($conn));
?>