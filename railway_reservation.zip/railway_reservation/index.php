<?php
session_start();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Indian Railways</title>
	<link  rel="stylesheet" href="css/bootstrap.min.css"/>
	<link  rel="stylesheet" href="css/bootstrap-theme.min.css"/>
	<link rel="stylesheet" href="css/main2.css">
	<link  rel="stylesheet" href="css/font.css">
	<link rel="shortcut icon" href="image/favicon.ico" type="image/ico" />
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/bootstrap.min.js"  type="text/javascript"></script>
 	<link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
	<?php if(@$_GET['w'])
{echo'<script>alert("'.@$_GET['w'].'");</script>';}
?>
<style>
.header{
		height: 156px;
		padding: 0;
		font-size: 14px;
		width:100%;
		background:white;
}
.logo{
		text-align:center;
		font-size:60pt;
		font-family:verdana,helvetica,arial,sans-serif;
		color:#054c89;
		padding-top:2pt;
}
.navbar{
	margin-top:10px;
}
.navbar .brand {
	padding:10px 20px 10px;
	font-size:20px;
	color:blue;
	
}
.span12{
	margin-right:0px;
	margin-left:30px;
}
.news {
	border-style:hidden;
	border-width:1px;
	float:right;
	padding:10px;
	margin-left:12px;
	width:28%;
	height:450px;
}
.footer
{
font-size:15px;
text-align:center;
border-top:1px solid;
border-color:#323232;
background-color:#054c89;
}
.footer a
{
margin:25px;
color:#ffffff;
text-decoration:none;
font: 15px "Century Gothic", "Times Roman", sans-serif;

}
.footer a:hover
{
text-decoration:none;
color:#050404;
border-bottom:1px solid;
border-color:#a3a1a1;

}
</style>
<script type="text/javascript" src="js/man.js"></script>
</head>
<body>
	<div class="header">
		<div class="row">
			<div style="float:left;width:150px;">
				<img src="image/logo.jpg"/>
			</div>		
			<div>
			<div class="col-lg-8 logo">
				<span>Indian Railways</span>
			</div>
			<div class="control-group" style="margin-left:35px;margin-top:40px;">
				<div class="controls">
				
				<?php
			 if(isset($_SESSION['name']))	
			 {
			 echo "Welcome,".$_SESSION['name']."&nbsp;&nbsp;&nbsp;<a href=\"logout.php\" class=\"btn btn-info\">Logout</a>";
			 }
			 else
			 {
			 ?>
					<a href="login1.php" class="pull-right btn btn-info" style="margin-right:20px;margin-top:20px;"><span class="glyphicon glyphicon-log-in" area-hidden="true" style="color:white"></span>&nbsp;<span class="title1" style="color:white"><b>Login</b></span></a>
					<a href="signup.php" class="pull-right btn btn-info"style="margin-right:20px;margin-top:20px;"><span class="glyphicon glyphicon-plus-sign" area-hidden="true" style="color:white"></span>&nbsp;<span class="title1" style="color:white"><b>Signup</b></span></a>
			 <?php } ?>
			
				</div>
			</div>

		</div>
	</div>
	
	</div>
	<div class="row">
		<div class="container">
		<div class="col-lg-12">
		<div class="navbar">
			<div class="navbar-inner pull-left">
				<div class="container" >
				<a class="brand" href="index.php" >HOME</a>
				<a class="brand" href="train.php" >FIND TRAIN</a>
				<a class="brand" href="reservation.php">RESERVATION</a>
				<a class="brand" href="profile.php">PROFILE</a>
				</div>
			</div>
		</div>
		</div>
		</div>
		</div>
	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="span12">
			<!-- Photos slider -->
			<div id="myCarousel" class="carousel slide" style="width:750px; float:left;margin-bottom:3px;">		
				<div class="carousel-inner">
				<div class="active item"><img src="image/1.jpg" style="width:750px;height:450px;"/></div>
				<div class="item"><img src="image/2.jpg" style="width:750px;height:450px;"/> </div>
				<div class="item"><img src="image/3.jpg" style="width:750px;height:450px;"/></div>
				<div class="item"><img src="image/4.jpg" style="width:750px;height:450px;"/></div>
				<div class="item"><img src="image/5.jpg" style="width:750px;height:450px;"/> </div>
				<div class="item"><img src="image/13.jpg"style="width:750px;height:450px;"/></div>
				
				</div>
				<a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
				<a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
			</div>
			
			
			<div class="news" Style="float:right;">
			<marquee behavior="scroll" id="marq"  scrollamount=3 direction="up" height="415px" onmouseover="nestop()" onmouseout="nestrt()">
				<div>
				<p style="color:#054c89;"><span class="glyphicon glyphicon-chevron-right"></span>&nbsp;<b>Indian Railways (reporting mark IR) is a State owned national transporter, and responsible for rail transport in India. It is owned and operated by the Government of India through the Ministry of Railways. It is the fourth largest railway network in the world comprising 119,630 kilometres (74,330 mi) of total track[4] and 92,081 km (57,216 mi) of running track over a route of 66,687 km (41,437 mi) with 7,216 stations at the end of 2015-16.</b></p>
				</br>
				<p style="color:#054c89;"><span class="glyphicon glyphicon-chevron-right"></span>&nbsp;<b>The first railway on Indian sub-continent ran over a stretch of 21 miles from Bombay to Thane. The idea of a railway to connect Bombay with Thane, Kalyan and with the Thal and Bhore Ghats inclines first occurred to Mr. George Clark, the Chief Engineer of the Bombay Government, during a visit to Bhandup in 1843.</b></p></br>
				<p style="color:#054c89;"><span class="glyphicon glyphicon-chevron-right"></span>&nbsp;<b> India's first bullet train, set to debut in 2023 between Prime Minister Narendra Modi's home state Gujarat and Maharashtra.</b></p></br>
				<p style="color:#054c89;"><span class="glyphicon glyphicon-chevron-right"></span>&nbsp;<b>The bullet train, using Japanese trains and technology, will cut the 500 km journey between Gujarat's Ahmedabad and Mumbai, India's financial capital, from eight hours now to just over three hours.</b></p></br>
				<p style="color:#054c89;"><span class="glyphicon glyphicon-chevron-right"></span>&nbsp;<b>Order food online while travelling in train or you can book your meal at the railway station anywhere in India, just download e-catering food on track from apps</b><p></br>
				</div>
			</marquee>
			
			</div>
		</div>
		</div>
		</div>
		</div></br>
		</br>
		
		<div class="row footer">
		<h4 class="footer-header">All Links</h4>
		<hr>
		<div class="col-md-2 col-md-offset-1 box ">
		<a href="http://www.nitsikkim.ac.in" target="_blank">NIT SIKKIM</a>
		</div>
		
		<div class="col-md-2 box">
		<a href="#" data-toggle="modal" data-target="#developers">Developer</a>
		</div>
		<div class="col-md-2 box">
		<a href="feedback.php" target="_blank">Feedback</a>
		</div>
		<div class="col-md-2 box">
		<a href="contactus.php" target="_blank">Contact Us</a>
		</div>
		<div id="google_translate_element" class="col-md-2 "></div>
			<script type="text/javascript">
			function googleTranslateElementInit() {
			new google.translate.TranslateElement({pageLanguage: 'en', multilanguagePage: true}, 'google_translate_element');
			}
			</script>
				<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
		<br/>
		<br/>
		<br/>
		<br/>
		<p class="copy">Copyright &copy; 2017  <span class="glyphicon glyphicon-heart-empty" style="color:red"></span>angalam Gupta All rights reserved.  | <a href="#">Home</a> | <a href="#">Disclaimer</a> | <a href="#">Sitemap</a> </p>
	</div>
	

	<div class="modal fade title1" id="developers">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"><span area-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<h4 class="modal-title" style="font-famile:'typo'"><span style="color:#343638">Developer</span></h4>
				</div>
				<div class="modal-body">
					<p>
						<div class="row">
						<h4 style="color:#343638" align="center"><b><u>Technical Developer</u></b></h4>
							<div class="col-md-4">
							<a href="https://www.facebook.com/mangalam.gupta.1" target="_blank" title="Mangalam Gupta">
							<img src="image/my_pic_id_card.jpg" height=125 width=175 alt="Mangalam Gupta" class="img-rounded">
							</a>
							</div>
							<div class="col-md-8">
								<a href="https://www.facebook.com/mangalam.gupta.1" style="color:#202020; font-size: 18px" title="Mangalam on Facebook" target="_blank">Mangalam Gupta</a>
								<h4 style="color:#202020  ; font-size:16px" class="title1">+91-7550851438</h4>
								<h4>b150073ee@nitsikkim.ac.in</h4>
								<a href="http://www.nitsikkim.ac.in" target="_blank" style="color:#202020" title="NIT SIKKIM">
								<h4>National Institute of Technology, Sikkim</h4>
								</a>
							</div><br/><br/>
						</div>
					</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>

	
</body>
</html>
<?php

if(isset($_SESSION['error']))
{
session_destroy();
}

?>